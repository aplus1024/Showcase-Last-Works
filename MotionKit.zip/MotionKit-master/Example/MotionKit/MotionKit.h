//
//  MotionKit.h
//  MotionKit
//
//  Created by Haroon on 19/02/2015.
//  Copyright (c) 2015 MotionKit. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MotionKit.
FOUNDATION_EXPORT double MotionKitVersionNumber;

//! Project version string for MotionKit.
FOUNDATION_EXPORT const unsigned char MotionKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MotionKit/PublicHeader.h>


