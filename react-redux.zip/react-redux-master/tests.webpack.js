const browserContext = require.context('./test/browser')
browserContext.keys().forEach(browserContext)
