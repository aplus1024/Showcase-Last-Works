
export const INCREASE = 'INCREASE'
export const DECREASE = 'DECREASE'
