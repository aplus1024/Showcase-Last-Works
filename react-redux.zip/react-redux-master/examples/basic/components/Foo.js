import React from 'react'

export default function Foo() {
  return <div>I am Foo!</div>
}
