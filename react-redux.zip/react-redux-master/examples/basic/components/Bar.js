import React from 'react'

export default function Bar() {
  return <div>And I am Bar!</div>
}
