//
//  QMErrorsFactory.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 1/13/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface QMErrorsFactory : NSObject

+ (NSError *)errorNotLoggedInREST;

@end
