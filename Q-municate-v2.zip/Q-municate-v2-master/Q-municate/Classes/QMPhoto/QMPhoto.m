//
//  QMPhoto.m
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 5/19/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMPhoto.h"

@implementation QMPhoto



@end
