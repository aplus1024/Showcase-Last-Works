//
//  QMShadowView.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 4/6/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QMShadowView : UIView

@end
