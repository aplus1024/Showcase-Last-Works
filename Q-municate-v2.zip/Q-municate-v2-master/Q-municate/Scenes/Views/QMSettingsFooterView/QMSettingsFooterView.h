//
//  QMSettingsFooterView.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 5/30/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QMSettingsFooterView : UIView

+ (CGFloat)preferredHeight;

@end
