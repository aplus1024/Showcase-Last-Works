//
//  QMNavigationBar.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 4/1/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QMNavigationBar : UINavigationBar

@property (weak, nonatomic) UIViewController *owner;

@end
