//
//  QMNavigationBar.m
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 4/1/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMNavigationBar.h"
#import "QMNotificationPanel.h"
#import <QMImageView.h>

@interface QMNavigationBar ()

@property (weak, nonatomic) UIView *notificationView;

@end

@implementation QMNavigationBar

- (void)layoutSubviews {
    [super layoutSubviews];
    
    for (UIView *view in self.subviews) {
        
        if ([NSStringFromClass([view class]) isEqualToString:@"_UINavigationBarBackground"]) {
            
            CGRect bounds = self.bounds;
            CGRect frame = view.frame;
            
            CGFloat statusBarHeight = CGRectGetHeight([UIApplication sharedApplication].statusBarFrame);
            frame.origin.y = bounds.origin.y + CGRectGetHeight(self.notificationView.frame) - statusBarHeight;
            frame.size.height = bounds.size.height + statusBarHeight;
            
            view.frame = frame;
        }
    }
}

- (void)didAddSubview:(UIView *)subview {
    
    if (self.owner != nil
        && subview.tag == kQMNotificationPanelTag) {
        self.notificationView = subview;
        
        CGRect frame = subview.frame;
        frame.origin.y += frame.size.height;
        subview.frame = frame;
        
        [self sizeToFit];
        self.transform = CGAffineTransformMakeTranslation(0, -(CGRectGetHeight(self.notificationView.frame)));
        
        [self.window.rootViewController.view layoutIfNeeded];
    }
}

- (void)willRemoveSubview:(UIView *)subview {
    
    if (self.owner != nil
        && subview.tag == kQMNotificationPanelTag) {
        self.notificationView = nil;
        
        self.transform = CGAffineTransformMakeTranslation(0, -(CGRectGetHeight(self.notificationView.frame)));
        [self sizeToFit];
        
        [self.window.rootViewController.view layoutIfNeeded];
    }
}

- (CGSize)sizeThatFits:(CGSize)size {
    
    if (self.owner == nil
        && self.superview == nil) {
        // if you will try to access super method when
        // super already released, you will receive
        // a bad access error
        return CGSizeZero;
    }
    
    CGSize sizeThatFits = [super sizeThatFits:size];
    
    if (self.notificationView) {
        
        sizeThatFits.height += CGRectGetHeight(self.notificationView.frame);
    }
    
    return sizeThatFits;
}

@end
