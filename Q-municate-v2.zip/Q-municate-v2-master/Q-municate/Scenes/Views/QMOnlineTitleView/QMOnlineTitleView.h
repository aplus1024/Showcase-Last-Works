//
//  QMOnlineTitleView.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 3/14/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMBaseTitleView.h"

@interface QMOnlineTitleView : QMBaseTitleView

- (void)setTitle:(NSString *)title;
- (void)setStatus:(NSString *)status;

@end
