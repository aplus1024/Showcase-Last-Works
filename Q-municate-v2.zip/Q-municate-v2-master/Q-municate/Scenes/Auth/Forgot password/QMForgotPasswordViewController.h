//
//  QMForgotPasswordTVC.h
//  Qmunicate
//
//  Created by Andrey Ivanov on 30.06.14.
//  Copyright (c) 2014 Quickblox. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QMForgotPasswordViewController : UITableViewController

@end
