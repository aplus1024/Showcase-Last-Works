//
//  QMGroupInfoViewController.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 4/5/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QMGroupInfoViewController : UIViewController

@property (strong, nonatomic) QBChatDialog *chatDialog;

@end

NS_ASSUME_NONNULL_END
