//
//  QMGroupNameViewController.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 5/23/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QMGroupNameViewController : UITableViewController

@property (strong, nonatomic) QBChatDialog *chatDialog;

@end

NS_ASSUME_NONNULL_END
