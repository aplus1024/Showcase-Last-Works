//
//  QMDialogsSearchDataProvider.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 3/2/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMSearchDataProvider.h"

@interface QMDialogsSearchDataProvider : QMSearchDataProvider

@end
