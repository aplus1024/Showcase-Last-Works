//
//  QMContactsSearchDataSource.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 3/17/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMContactsDataSource.h"
#import "QMSearchProtocols.h"

@interface QMContactsSearchDataSource : QMContactsDataSource <QMContactsSearchDataSourceProtocol>

@end
