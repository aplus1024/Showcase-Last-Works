//
//  QMLeaveChatCell.m
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 4/5/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMLeaveChatCell.h"

@implementation QMLeaveChatCell

+ (CGFloat)height {
    
    return 44.0f;
}

- (UIEdgeInsets)layoutMargins {
    
    return UIEdgeInsetsZero;
}

@end
