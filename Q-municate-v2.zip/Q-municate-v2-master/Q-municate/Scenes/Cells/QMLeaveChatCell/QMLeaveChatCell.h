//
//  QMLeaveChatCell.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 4/5/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMTableViewCell.h"

@interface QMLeaveChatCell : QMTableViewCell

@end
