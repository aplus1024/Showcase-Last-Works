//
//  QMContactCell.m
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 3/15/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMContactCell.h"

@implementation QMContactCell

+ (CGFloat)height {
    
    return 50.0f;
}

@end
