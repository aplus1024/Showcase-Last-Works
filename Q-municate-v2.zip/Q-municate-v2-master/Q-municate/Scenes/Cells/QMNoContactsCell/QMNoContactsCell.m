//
//  QMNoContactsCell.m
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 3/16/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMNoContactsCell.h"

@implementation QMNoContactsCell

+ (CGFloat)height {
    
    return 210.0f;
}

@end
