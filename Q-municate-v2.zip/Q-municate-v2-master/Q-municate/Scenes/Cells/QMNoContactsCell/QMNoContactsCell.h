//
//  QMNoContactsCell.h
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 3/16/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMTableViewCell.h"

@interface QMNoContactsCell : QMTableViewCell

@end
