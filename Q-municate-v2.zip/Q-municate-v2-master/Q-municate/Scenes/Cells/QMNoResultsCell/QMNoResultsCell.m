//
//  QMNoResultsCell.m
//  Q-municate
//
//  Created by Vitaliy Gorbachov on 3/4/16.
//  Copyright © 2016 Quickblox. All rights reserved.
//

#import "QMNoResultsCell.h"

@implementation QMNoResultsCell

+ (CGFloat)height {
    
    return 82.0f;
}

@end
