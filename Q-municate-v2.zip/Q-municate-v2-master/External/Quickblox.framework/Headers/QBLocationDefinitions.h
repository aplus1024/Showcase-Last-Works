/*
 *  Definitions.h
 *  LocationService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */


#import <Quickblox/QBLocationEnums.h>
#import <Quickblox/QBLocationStructs.h>