/*
 *  Defnitions.h
 *  MessagesService
 *

 *  Copyright 2011 QuickBlox team. All rights reserved.
 *
 */

#import <Quickblox/QBPushNotificationsConsts.h>
#import <Quickblox/QBPushNotificationsEnums.h>
