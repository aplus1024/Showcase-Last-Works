This code was created at Seedstars Labs (www.seedstarslabs.com) for internal use. 

The JS part was inspired from the excellent [React-redux-jwt-auth-example](https://github.com/joshgeller/react-redux-jwt-auth-example).

- Fernando Ferreira <fernando.ferreira@seedstarslabs.com>
- Luis Rodrigues <luis.rodrigues@seedstarslabs.com>
- Pedro Gomes <pedro.gomes@seedstarslabs.com>
- Ruben Almeida <ruben.almeida@seedstarslabs.com>
