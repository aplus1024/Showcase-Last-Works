import React from 'react';

export default class NotFoundView extends React.Component {

    render() {
        return (
            <div>
                <h1>NOT FOUND</h1>
            </div>
        );
    }

}
