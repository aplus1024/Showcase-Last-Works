"use strict";
exports.HEROES = [
    { id: 11, name: 'Mr.Nice' },
    { id: 15, name: 'Mr.Kang' },
    { id: 23, name: 'Miss.Mu' }
];
//# sourceMappingURL=mock-heroes.js.map