export class Dash{
	id:number;
	regions: string;
	st_a:number;
	st_na:number;
	contracts_sum:number;
	customers_sum:number;
}
