import {Hero} from './hero';

export const HEROES:Hero[]=[
{id:11,name:'Mr.Nice'},
{id:15,name:'Mr.Kang'},
{id:23,name:'Miss.Mu'}
]
